import{_ as t,y as n,A as c,z as o}from"#entry";const r={};function a(s,e){return o(),n("div",null,[...e[0]||(e[0]=[c("h1",null,"contact",-1)])])}const _=t(r,[["render",a]]);export{_ as default};
